package com.example.gripmod;
import net.minecraft.creativetabs.CreativeTabs;
import net.minecraft.item.Item;
public class ItemGlove extends Item { public ItemGlove() { setCreativeTab(CreativeTabs.MISC); setMaxStackSize(1); } }