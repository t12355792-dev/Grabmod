package com.example.gripmod;
import net.minecraft.creativetabs.CreativeTabs;
import net.minecraft.item.Item;
public class ItemSpeedometer extends Item { public ItemSpeedometer() { setCreativeTab(CreativeTabs.MISC); setMaxStackSize(1); } }