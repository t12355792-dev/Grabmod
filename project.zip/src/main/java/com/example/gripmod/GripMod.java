package com.example.gripmod;
import net.minecraft.item.Item;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.RegistryEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.registry.GameRegistry;
@Mod(modid="gripmod", name="Grip Mod", version="1.0")
@Mod.EventBusSubscriber
public class GripMod {
 public static final String MODID="gripmod";
 @GameRegistry.ObjectHolder("gripmod:glove_item")
 public static final Item GLOVE_ITEM = null;
 @GameRegistry.ObjectHolder("gripmod:speedometer_item")
 public static final Item SPEEDOMETER_ITEM = null;
 @Mod.EventHandler
 public void init(FMLInitializationEvent e) { MinecraftForge.EVENT_BUS.register(new GripEventHandler()); }
 @SubscribeEvent
 public static void r(RegistryEvent.Register<Item> event) {
 event.getRegistry().register(new ItemGlove().setRegistryName("glove_item").setUnlocalizedName("glove_item"));
 event.getRegistry().register(new ItemSpeedometer().setRegistryName("speedometer_item").setUnlocalizedName("speedometer_item"));
 }
}